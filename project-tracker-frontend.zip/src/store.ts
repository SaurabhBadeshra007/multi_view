
import { create } from 'zustand'

export type Status = 'todo' | 'progress' | 'review' | 'done'

export interface Task {
  id: number
  title: string
  status: Status
  priority: 'low' | 'medium' | 'high' | 'critical'
  dueDate: string
}

interface State {
  tasks: Task[]
  view: 'kanban' | 'list' | 'timeline'
  setView: (v: State['view']) => void
  moveTask: (id: number, status: Status) => void
}

const sampleTasks: Task[] = Array.from({ length: 50 }).map((_, i) => ({
  id: i,
  title: `Task ${i + 1}`,
  status: ['todo','progress','review','done'][Math.floor(Math.random()*4)] as Status,
  priority: ['low','medium','high','critical'][Math.floor(Math.random()*4)] as any,
  dueDate: new Date(Date.now() + i*86400000).toISOString()
}))

export const useStore = create<State>((set) => ({
  tasks: sampleTasks,
  view: 'kanban',
  setView: (view) => set({ view }),
  moveTask: (id, status) =>
    set((state) => ({
      tasks: state.tasks.map(t => t.id === id ? { ...t, status } : t)
    }))
}))
