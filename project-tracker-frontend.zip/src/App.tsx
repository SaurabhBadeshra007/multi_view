
import React from 'react'
import Kanban from './views/Kanban'
import ListView from './views/ListView'
import Timeline from './views/Timeline'
import { useStore } from './store'

export default function App() {
  const { view, setView } = useStore()

  return (
    <div className="app">
      <header className="header">
        <h1>Project Tracker</h1>
        <div className="tabs">
          <button onClick={() => setView('kanban')}>Kanban</button>
          <button onClick={() => setView('list')}>List</button>
          <button onClick={() => setView('timeline')}>Timeline</button>
        </div>
      </header>

      {view === 'kanban' && <Kanban />}
      {view === 'list' && <ListView />}
      {view === 'timeline' && <Timeline />}
    </div>
  )
}
