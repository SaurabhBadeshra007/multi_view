
import React from 'react'
import { useStore } from '../store'

export default function Timeline() {
  const { tasks } = useStore()

  return (
    <div className="timeline">
      {tasks.map(task => (
        <div key={task.id} className="timeline-bar">
          {task.title}
        </div>
      ))}
    </div>
  )
}
