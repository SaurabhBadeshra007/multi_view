
import React from 'react'
import { useStore, Status } from '../store'

const columns: { title: string; key: Status }[] = [
  { title: 'To Do', key: 'todo' },
  { title: 'In Progress', key: 'progress' },
  { title: 'In Review', key: 'review' },
  { title: 'Done', key: 'done' }
]

export default function Kanban() {
  const { tasks, moveTask } = useStore()

  const onDragStart = (e: React.DragEvent, id: number) => {
    e.dataTransfer.setData('id', String(id))
  }

  const onDrop = (e: React.DragEvent, status: Status) => {
    const id = Number(e.dataTransfer.getData('id'))
    moveTask(id, status)
  }

  return (
    <div className="kanban">
      {columns.map(col => (
        <div key={col.key}
          className="column"
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => onDrop(e, col.key)}
        >
          <h3>{col.title}</h3>

          {tasks.filter(t => t.status === col.key).map(task => (
            <div key={task.id}
              className="card"
              draggable
              onDragStart={(e) => onDragStart(e, task.id)}
            >
              <h4>{task.title}</h4>
              <p>Priority: {task.priority}</p>
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}
